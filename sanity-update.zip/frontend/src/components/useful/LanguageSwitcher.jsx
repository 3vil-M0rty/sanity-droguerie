import { useState, useRef, useEffect, useContext } from 'react';
import { Globe, Check, ChevronDown } from 'lucide-react';
import { I18nContext } from '../../context/i18nContext';

const LANGUAGE_META = {
  en: { code: 'EN', name: 'English' },
  fr: { code: 'FR', name: 'Français' },
  ar: { code: 'AR', name: 'العربية' },
  es: { code: 'ES', name: 'Español' },
  pt: { code: 'PT', name: 'Português' },
  de: { code: 'DE', name: 'Deutsch' },
};

// `compact`: globe icon only (collapsed sidebar); the list opens to the right.
export default function LanguageSwitcher({ compact = false }) {
  const { language, setLanguage, supportedLanguages } = useContext(I18nContext);

  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(supportedLanguages.indexOf(language));
  const rootRef = useRef(null);

  // Keep the keyboard-highlighted row in sync if the active language
  // changes from outside this component (e.g. another switcher on the page)
  useEffect(() => {
    setHighlight(supportedLanguages.indexOf(language));
  }, [language, supportedLanguages]);

  useEffect(() => {
    function onClickOutside(e) {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    }
    function onEsc(e) {
      if (e.key === 'Escape') setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    document.addEventListener('keydown', onEsc);
    return () => {
      document.removeEventListener('mousedown', onClickOutside);
      document.removeEventListener('keydown', onEsc);
    };
  }, []);

  const select = (lang) => {
    setLanguage(lang); // this is changeLanguage() from I18nProvider
    setOpen(false);
  };

  const onKeyDown = (e) => {
    if (!open && (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault();
      setOpen(true);
      return;
    }
    if (!open) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlight((h) => Math.min(h + 1, supportedLanguages.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      select(supportedLanguages[highlight]);
    }
  };

  const meta = LANGUAGE_META[language];

  return (
    <div
      ref={rootRef}
      style={{
        position: 'relative',
        display: 'inline-block',
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      }}
    >
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        onKeyDown={onKeyDown}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={compact ? meta.name : undefined}
        title={compact ? meta.name : undefined}
        style={compact ? {
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          width: '36px',
          height: '36px',
          padding: 0,
          background: open ? 'var(--color-bg-tertiary)' : 'transparent',
          border: 'none',
          borderRadius: '6px',
          color: 'var(--color-text-secondary)',
          cursor: 'pointer',
        } : {
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '6px 10px',
          background: open ? 'var(--color-bg-tertiary)' : 'var(--color-bg-primary)',
          border: '1px solid var(--color-border)',
          borderRadius: '6px',
          color: 'var(--color-text-primary)',
          fontSize: '13px',
          fontWeight: 500,
          lineHeight: 1.2,
          cursor: 'pointer',
          transition: 'background-color 0.15s ease',
        }}
      >
        {compact ? (
          <Globe size={16} strokeWidth={1.75} />
        ) : (
          <>
            <Globe size={14} color="#999999" strokeWidth={1.75} />
            <span>{meta.name}</span>
            <ChevronDown
              size={14}
              color="#808080"
              strokeWidth={2}
              style={{
                transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
                transition: 'transform 0.15s ease',
              }}
            />
          </>
        )}
      </button>

      {open && (
        <ul
          role="listbox"
          style={{
            position: 'absolute',
            ...(compact
              ? { bottom: 0, left: 'calc(100% + 10px)' }
              : { bottom: 'calc(100% + 6px)', left: 0 }),
            minWidth: '180px',
            margin: 0,
            padding: '4px',
            listStyle: 'none',
            background: 'var(--color-bg-primary)',
            border: '1px solid var(--color-border)',
            borderRadius: '8px',
            boxShadow: '0 8px 24px var(--color-shadow-lg)',
            zIndex: 50,
          }}
        >
          {supportedLanguages.map((lang, i) => {
            const isActive = lang === language;
            const isHighlighted = i === highlight;
            return (
              <li
                key={lang}
                role="option"
                aria-selected={isActive}
                onMouseEnter={() => setHighlight(i)}
                onClick={() => select(lang)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '10px',
                  padding: '7px 8px',
                  borderRadius: '5px',
                  fontSize: '13px',
                  color: isActive ? 'var(--color-text-primary)' : 'var(--color-text-secondary)',
                  background: isHighlighted ? 'var(--color-bg-tertiary)' : 'transparent',
                  cursor: 'pointer',
                }}
              >
                <span style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span
                    style={{
                      fontSize: '10px',
                      fontWeight: 600,
                      letterSpacing: '0.02em',
                      color: 'var(--color-text-muted)',
                      background: 'var(--color-bg-secondary)',
                      border: '1px solid var(--color-border)',
                      borderRadius: '4px',
                      padding: '2px 5px',
                      minWidth: '26px',
                      textAlign: 'center',
                    }}
                  >
                    {LANGUAGE_META[lang].code}
                  </span>
                  <span>{LANGUAGE_META[lang].name}</span>
                </span>
                {isActive && <Check size={14} color="#10b981" strokeWidth={2.5} />}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}